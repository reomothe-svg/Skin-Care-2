﻿using System.Collections.Generic;

namespace SkinCare
{
    public interface ISkinAnalyzer
    {
        string AnalyzeSkin(int[] answers);
        List<Product> GetRecommendedProducts(string skinType);
    }
}