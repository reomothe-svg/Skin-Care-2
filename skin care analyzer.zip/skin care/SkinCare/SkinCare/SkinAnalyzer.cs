﻿using System.Collections.Generic;

namespace SkinCare
{
    public class User
    {
        private string name;
        private int age;
        private int[] quizAnswers;
        private SkinType detectedSkinType;

        public User(string name, int age)
        {
            this.name = name;
            this.age = age;
            this.quizAnswers = new int[8];
        }

        public string GetName() { return name; }
        public int GetAge() { return age; }
        public int[] GetQuizAnswers() { return quizAnswers; }
        public SkinType GetDetectedSkinType() { return detectedSkinType; }

        public void SetName(string name) { this.name = name; }
        public void SetAge(int age) { this.age = age; }
        public void SetDetectedSkinType(SkinType skinType) { this.detectedSkinType = skinType; }

        public void SetAnswer(int questionIndex, int answer)
        {
            if (questionIndex >= 0 && questionIndex < quizAnswers.Length)
                quizAnswers[questionIndex] = answer;
        }
    }

    public class SkinAnalyzer : ISkinAnalyzer
    {
        public string AnalyzeSkin(int[] answers)
        {
            int score = 0;
            for (int i = 0; i < answers.Length; i++)
                score += answers[i];

            if (answers[2] >= 3 && answers[5] >= 3) return "Sensitive";
            if (score >= 24) return "Oily";
            if (score <= 12) return "Dry";
            if (answers[0] >= 3 && answers[1] >= 2) return "Combination";
            return "Normal";
        }

        public List<Product> GetRecommendedProducts(string skinType)
        {
            SkinType skin = CreateSkinType(skinType);
            return skin.GetRecommendedProducts();
        }

        public SkinType CreateSkinType(string skinType)
        {
            if (skinType == "Oily") return new OilySkin();
            else if (skinType == "Dry") return new DrySkin();
            else if (skinType == "Sensitive") return new SensitiveSkin();
            else if (skinType == "Combination") return new CombinationSkin();
            else return new NormalSkin();
        }
    }
}