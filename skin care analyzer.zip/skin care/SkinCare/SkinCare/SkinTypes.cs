﻿using System.Collections.Generic;

namespace SkinCare
{
    public abstract class SkinType
    {
        protected string typeName;
        protected string description;
        protected string emoji;

        public string GetTypeName() { return typeName; }
        public string GetDescription() { return description; }
        public string GetEmoji() { return emoji; }

        public abstract List<Product> GetRecommendedProducts();
        public abstract List<string> GetSkinCareRoutine();
        public abstract string GetSkinTips();
    }

    public class OilySkin : SkinType
    {
        public OilySkin()
        {
            typeName = "البشرة الدهنية";
            description = "بشرتك لامعة وتنتج زيوتاً زائدة، خصوصاً في منطقة T-zone";
            emoji = "✨";
        }
        public override List<Product> GetRecommendedProducts()
        {
            return new List<Product>
            {
                new Product("غسول الفحم النشط", "ينظف المسام ويقلل الدهون", "غسول", 15.99),
                new Product("تونر حمض الساليسيليك", "يقلل البشرة الدهنية ويمنع الحبوب", "تونر", 12.50),
                new Product("مرطب خفيف بدون زيوت", "ترطيب بدون إضافة دهون", "مرطب", 18.00),
                new Product("واقي شمس Gel", "حماية من الشمس بتركيبة خفيفة", "واقي شمس", 22.00),
                new Product("ماسك الطين الأسود", "يمتص الزيوت الزائدة من المسام", "ماسك", 14.99)
            };
        }
        public override List<string> GetSkinCareRoutine()
        {
            return new List<string>
            {
                "صباحاً: غسل الوجه بالغسول المخصص",
                "تونر لتضييق المسام",
                "مرطب خفيف بدون زيوت",
                "واقي شمس Gel",
                "مساءً: غسل الوجه جيداً",
                "تونر بحمض الساليسيليك",
                "سيروم نياسيناميد",
                "مرطب ليلي خفيف"
            };
        }
        public override string GetSkinTips()
        {
            return "نصائح للبشرة الدهنية:\n- لا تغسلي وجهك أكثر من مرتين يومياً\n- استخدمي مناديل ورقية لامتصاص الزيوت\n- تجنبي المنتجات الثقيلة\n- اشربي ماء كافياً\n- ماسك الطين مرة أسبوعياً";
        }
    }

    public class DrySkin : SkinType
    {
        public DrySkin()
        {
            typeName = "البشرة الجافة";
            description = "بشرتك تحتاج ترطيباً مستمراً وتشعرين بالشد أحياناً";
            emoji = "🌵";
        }
        public override List<Product> GetRecommendedProducts()
        {
            return new List<Product>
            {
                new Product("غسول كريمي مرطب", "ينظف بلطف دون تجفيف", "غسول", 16.99),
                new Product("تونر بالهيالورونيك", "يضيف رطوبة عميقة", "تونر", 13.50),
                new Product("مرطب كثيف بالشيا بتر", "ترطيب عميق يدوم طويلاً", "مرطب", 24.00),
                new Product("زيت الأرغان", "يغذي ويرطب البشرة", "زيت", 29.99),
                new Product("ماسك العسل والأفوكادو", "ماسك مرطب ومغذي", "ماسك", 17.50)
            };
        }
        public override List<string> GetSkinCareRoutine()
        {
            return new List<string>
            {
                "صباحاً: غسول كريمي لطيف",
                "تونر بالهيالورونيك على بشرة رطبة",
                "سيروم مرطب",
                "مرطب كثيف",
                "واقي شمس مرطب",
                "مساءً: مزيل مكياج لطيف",
                "زيت مغذي",
                "مرطب ليلي كثيف"
            };
        }
        public override string GetSkinTips()
        {
            return "نصائح للبشرة الجافة:\n- اشربي ماء كثير\n- تجنبي الماء الساخن\n- رطبي وجهك وهو رطب\n- تجنبي منتجات الكحول";
        }
    }

    public class NormalSkin : SkinType
    {
        public NormalSkin()
        {
            typeName = "البشرة العادية";
            description = "بشرتك متوازنة ومشرقة - محظوظة!";
            emoji = "🌟";
        }
        public override List<Product> GetRecommendedProducts()
        {
            return new List<Product>
            {
                new Product("غسول جل متوازن", "ينظف بلطف", "غسول", 14.99),
                new Product("تونر بالنياسيناميد", "يحافظ على التوهج", "تونر", 11.50),
                new Product("مرطب متوسط", "ترطيب مناسب", "مرطب", 19.00),
                new Product("سيروم فيتامين C", "يحافظ على الإشراقة", "سيروم", 25.00),
                new Product("واقي شمس SPF50", "حماية يومية", "واقي شمس", 20.00)
            };
        }
        public override List<string> GetSkinCareRoutine()
        {
            return new List<string>
            {
                "صباحاً: غسول لطيف",
                "تونر",
                "سيروم فيتامين C",
                "مرطب خفيف",
                "واقي شمس",
                "مساءً: غسول",
                "مرطب ليلي",
                "مقشر لطيف أسبوعياً"
            };
        }
        public override string GetSkinTips()
        {
            return "نصائح للبشرة العادية:\n- حافظي على روتينك\n- واقي الشمس يومياً\n- لا تبالغي في المنتجات\n- نوم كافٍ وتغذية سليمة";
        }
    }

    public class SensitiveSkin : SkinType
    {
        public SensitiveSkin()
        {
            typeName = "البشرة الحساسة";
            description = "بشرتك تتفاعل بسرعة مع المنتجات والعوامل الخارجية";
            emoji = "🌸";
        }
        public override List<Product> GetRecommendedProducts()
        {
            return new List<Product>
            {
                new Product("Micellar Water", "ينظف بلطف شديد", "غسول", 13.99),
                new Product("تونر الألوة فيرا", "يهدئ ويرطب", "تونر", 12.00),
                new Product("مرطب بالسيراميد", "يقوي حاجز البشرة", "مرطب", 22.00),
                new Product("كريم النياسيناميد", "يهدئ الاحمرار", "سيروم", 19.99),
                new Product("واقي شمس المعادن", "واقي لطيف", "واقي شمس", 26.00)
            };
        }
        public override List<string> GetSkinCareRoutine()
        {
            return new List<string>
            {
                "صباحاً: Micellar Water",
                "تونر مهدئ بدون كحول",
                "مرطب بالسيراميد",
                "واقي شمس معادن",
                "مساءً: تنظيف لطيف",
                "سيروم مهدئ",
                "مرطب ليلي مهدئ"
            };
        }
        public override string GetSkinTips()
        {
            return "نصائح للبشرة الحساسة:\n- جربي كل منتج على منطقة صغيرة أولاً\n- تجنبي المنتجات ذات الرائحة\n- لا تبالغي في التقشير\n- استشيري طبيب جلدية";
        }
    }

    public class CombinationSkin : SkinType
    {
        public CombinationSkin()
        {
            typeName = "البشرة المختلطة";
            description = "بشرتك دهنية في منطقة T-zone وجافة في الخدين";
            emoji = "☯️";
        }
        public override List<Product> GetRecommendedProducts()
        {
            return new List<Product>
            {
                new Product("غسول متوازن", "ينظف دون إفراط", "غسول", 15.50),
                new Product("تونر النياسيناميد", "يوازن إنتاج الزيت", "تونر", 13.00),
                new Product("مرطب Gel-Cream", "ترطيب متوازن", "مرطب", 21.00),
                new Product("سيروم الهيالورونيك", "ترطيب لكل المناطق", "سيروم", 18.99),
                new Product("ماسك مزدوج", "طين على T-zone ومرطب على الخدين", "ماسك", 16.00)
            };
        }
        public override List<string> GetSkinCareRoutine()
        {
            return new List<string>
            {
                "صباحاً: غسول متوازن",
                "تونر موحد",
                "مرطب Gel للمناطق الدهنية",
                "واقي شمس",
                "مساءً: تنظيف جيد",
                "سيروم مرطب",
                "مرطب خفيف",
                "ماسك مزدوج أسبوعياً"
            };
        }
        public override string GetSkinTips()
        {
            return "نصائح للبشرة المختلطة:\n- منتجات مختلفة لمناطق مختلفة\n- ماسك مزدوج أسبوعياً\n- تجنبي المنتجات الثقيلة على T-zone\n- البساطة في الروتين أفضل";
        }
    }
}